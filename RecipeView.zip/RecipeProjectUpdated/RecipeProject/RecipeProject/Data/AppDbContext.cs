﻿
using Microsoft.EntityFrameworkCore;
using RecipeProject.Models;

namespace RecipeProject.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions options) : base(options)
        {
        }
        public DbSet<Recipe> Recipes { get; set; }
    }
}
