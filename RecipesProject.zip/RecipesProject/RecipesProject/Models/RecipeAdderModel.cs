﻿using Microsoft.AspNetCore.Mvc;

namespace RecipesProject.Models
{
    public class RecipeAdderModel : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
