﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RecipeProject.Data;
using RecipeProject.Models;

namespace RecipeProject.Controllers
{
    public class RecipeController : Controller
    {
        private readonly AppDbContext appDb;

        public RecipeController(AppDbContext appDb)
        {
            this.appDb = appDb;
        }
        [HttpGet]
        public async Task<IActionResult> GetResults()
        {
            var recipeObj= await  appDb.Recipes.ToListAsync();
            return View(recipeObj);
        }
            [HttpGet]

        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Add(AddRecipeViewModel request)
        {
            var recipeObj = new Recipe()
            {
                id = Guid.NewGuid(),
                recipe = request.recipe,
                author = request.author,
                date = request.date,
                ingredients = request.ingredients,
                instructions = request.instructions
            };
            await appDb.Recipes.AddAsync(recipeObj);
            await appDb.SaveChangesAsync();
            return Redirect("GetResults");
        }
        [HttpGet]
        public async Task<IActionResult> ViewRecipe(Guid id) 
        {
            var recipeObj= await appDb.Recipes.FirstOrDefaultAsync(x => x.id == id);
            if(recipeObj != null) { 
            var viewModel = new UpdateRecipeViewModel
            {
                id = recipeObj.id,
                recipe = recipeObj.recipe,
                author = recipeObj.author,
                date = recipeObj.date,
                ingredients = recipeObj.ingredients,
                instructions = recipeObj.instructions
            };
            return await Task.Run(()=>View("ViewRecipe",viewModel));
            }
            return RedirectToAction("GetResults");
        }
        [HttpPost]
        public async Task<IActionResult> ViewRecipe (UpdateRecipeViewModel model)
        {
            var recipeObj = await appDb.Recipes.FindAsync(model.id);
            if (recipeObj != null)
            {
                
                    recipeObj.id = model.id;
                    recipeObj.recipe=model.recipe;
                    recipeObj.author=model.author;
                    recipeObj.date=model.date;
                    recipeObj.ingredients=model.ingredients;
                    recipeObj.instructions=model.instructions;
                    await appDb.SaveChangesAsync();
                    return RedirectToAction("GetResults");
            }
                
            
            return RedirectToAction("GetResults");
        }

        [HttpPost]
        public async Task<IActionResult> Delete(UpdateRecipeViewModel model)
        {

            var recipeObj = await appDb.Recipes.FindAsync(model.id);
            if (recipeObj != null)
            {
                appDb.Recipes.Remove(recipeObj);
                appDb.SaveChangesAsync();
                return RedirectToAction("GetResults");
            }
            return RedirectToAction("GetResults");
        }
    }
}
