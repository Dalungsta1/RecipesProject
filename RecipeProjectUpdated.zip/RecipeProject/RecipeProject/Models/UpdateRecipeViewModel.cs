﻿namespace RecipeProject.Models
{
    public class UpdateRecipeViewModel
    {
        public Guid id { get; set; }
        public string author { get; set; }
        public string instructions { get; set; }
        public string ingredients { get; set; }
        public string recipe { get; set; }
        public DateTime date { get; set; }
    }
}
