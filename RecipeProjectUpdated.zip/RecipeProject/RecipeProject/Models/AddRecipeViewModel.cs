﻿namespace RecipeProject.Models
{
    public class AddRecipeViewModel
    {
        public string author { get; set; }
        public string instructions { get; set; }
        public string ingredients { get; set; }
        public string recipe { get; set; }
        public DateTime date { get; set; }
    }
}
